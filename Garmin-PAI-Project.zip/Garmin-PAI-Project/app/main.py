"""Application entry point.  Run from the project root:

    uvicorn app.main:app --reload
"""
from fastapi import FastAPI

from app.api_handler import router
from app.models import init_db

app = FastAPI(title="Garmin PAI IoT Platform")


@app.on_event("startup")
def on_startup():
    init_db()


app.include_router(router)
